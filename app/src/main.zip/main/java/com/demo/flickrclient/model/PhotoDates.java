package com.demo.flickrclient.model;

public class PhotoDates {

    private String taken;

    public String getTaken ()
    {
        return taken;
    }

}
