package com.demo.flickrclient.model;

public class PhotoCommentsResponse extends FlickrResponse{

    private PhotoComments comments;

    public PhotoComments getComments()
    {
        return comments;
    }

}
