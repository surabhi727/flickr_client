package com.demo.flickrclient.model;

public class Photos {

    private String total;

    private String page;

    private String pages;

    private PhotoListItem[] photo;

    private String perpage;

    public PhotoListItem[] getPhoto() {
        return photo;
    }

}

